#define __CLC_FUNCTION atomic_add
#include <clc/atomic/atomic_decl.inc>
