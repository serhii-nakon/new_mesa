_CLC_DECL size_t get_global_offset(uint dim);
