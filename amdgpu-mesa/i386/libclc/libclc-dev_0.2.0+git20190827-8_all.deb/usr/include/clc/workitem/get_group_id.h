_CLC_DECL size_t get_group_id(uint dim);
