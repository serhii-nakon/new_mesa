_CLC_DECL uint get_work_dim(void);
