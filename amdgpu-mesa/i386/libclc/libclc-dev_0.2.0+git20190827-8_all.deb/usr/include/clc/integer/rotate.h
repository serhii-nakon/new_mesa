#define __CLC_BODY <clc/integer/rotate.inc>
#include <clc/integer/gentype.inc>
