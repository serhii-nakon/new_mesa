_CLC_OVERLOAD _CLC_DECL int atom_dec(volatile global int *p);
_CLC_OVERLOAD _CLC_DECL unsigned int atom_dec(volatile global unsigned int *p);
