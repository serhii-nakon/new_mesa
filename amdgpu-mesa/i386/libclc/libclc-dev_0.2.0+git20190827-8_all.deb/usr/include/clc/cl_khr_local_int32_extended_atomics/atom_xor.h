#define __CLC_FUNCTION atom_xor
#define __CLC_ADDRESS_SPACE local
#include <clc/atom_decl_int32.inc>
