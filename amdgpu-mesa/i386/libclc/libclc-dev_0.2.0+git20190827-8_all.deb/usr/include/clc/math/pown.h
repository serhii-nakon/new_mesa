#define __CLC_BODY <clc/math/pown.inc>
#include <clc/math/gentype.inc>
#undef __CLC_BODY
