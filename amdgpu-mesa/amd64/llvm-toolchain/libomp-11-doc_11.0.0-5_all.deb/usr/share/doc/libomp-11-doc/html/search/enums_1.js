var searchData=
[
  ['sched_5ftype',['sched_type',['../group__WORK__SHARING.html#ga56ebd4fa33cbb0497e6157bb3f04d0e2',1,'kmp.h']]],
  ['stats_5fflags_5fe',['stats_flags_e',['../group__STATS__GATHERING.html#ga438c2840cc2d516238ea3eb0f4c116b3',1,'kmp_stats.h']]],
  ['stats_5fstate_5fe',['stats_state_e',['../group__STATS__GATHERING.html#gaceceb28b590e725a5106b6c90a451243',1,'kmp_stats.h']]]
];
