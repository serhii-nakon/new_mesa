var searchData=
[
  ['startup_20and_20shutdown',['Startup and Shutdown',['../group__STARTUP__SHUTDOWN.html',1,'']]],
  ['statistics_20gathering_20from_20omptb',['Statistics Gathering from OMPTB',['../group__STATS__GATHERING.html',1,'']]],
  ['synchronization',['Synchronization',['../group__SYNCHRONIZATION.html',1,'']]]
];
