var searchData=
[
  ['wait_2frelease_20operations',['Wait/Release operations',['../group__WAIT__RELEASE.html',1,'']]],
  ['work_20sharing',['Work Sharing',['../group__WORK__SHARING.html',1,'']]]
];
